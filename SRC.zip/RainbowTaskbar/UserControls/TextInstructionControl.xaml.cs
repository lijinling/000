﻿using System.Windows.Controls;

namespace RainbowTaskbar.UserControls;

/// <summary>
///     Interaction logic for TextInstructionControl.xaml
/// </summary>
public partial class TextInstructionControl : UserControl {
    public TextInstructionControl() {
        InitializeComponent();
    }
}