﻿using System.Windows.Controls;

namespace RainbowTaskbar.UserControls;

/// <summary>
///     Interaction logic for BorderRadiusControl.xaml
/// </summary>
public partial class BorderRadiusInstructionControl : UserControl {
    public BorderRadiusInstructionControl() {
        InitializeComponent();
    }
}