﻿using System.Windows.Controls;

namespace RainbowTaskbar.UserControls;

/// <summary>
///     Interaction logic for TransparencyInstructionControl.xaml
/// </summary>
public partial class TransparencyInstructionControl : UserControl {
    public TransparencyInstructionControl() {
        InitializeComponent();
    }
}