﻿using System.Windows.Controls;

namespace RainbowTaskbar.UserControls;

/// <summary>
///     Interaction logic for ClearLayerInstructionControl.xaml
/// </summary>
public partial class ClearLayerInstructionControl : UserControl {
    public ClearLayerInstructionControl() {
        InitializeComponent();
    }
}