﻿using System.Windows.Controls;

namespace RainbowTaskbar.UserControls;

/// <summary>
///     Interaction logic for DelayInstructionControl.xaml
/// </summary>
public partial class DelayInstructionControl : UserControl {
    public DelayInstructionControl() {
        InitializeComponent();
    }
}